
$(document).ready(function(){

    $('#dropdown').click(function() {
        $('.dropdown_menu').slideToggle('active_menu'),
            $('#dropdown').toggleClass('toggle')
    });


});

var mySwiper = new Swiper ('.swiper-container', {
    // Optional parameter
    loop: false,

    // Navigation arrows
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },

    // Default parameters
    slidesPerView: 4,
    spaceBetween: 30,
    // Responsive breakpoints
    breakpoints: {
        // when window width is <= 320px
        320: {
            slidesPerView: 1,
            spaceBetween: 10
        },
        // when window width is <= 480px
        480: {
            slidesPerView: 1,
            spaceBetween: 20
        },
        // when window width is <= 640px
        992: {
            slidesPerView: 3,
            spaceBetween: 30
        }
    }
});